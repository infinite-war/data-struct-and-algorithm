for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(ans[i][j]==INT_MAX){
                cout<<"N ";
            }
            else cout<<ans[i][j]<<" ";
        }
        cout<<endl;
    }